﻿#include "OpenQinling_C_Initblock.h"
#pragma execution_character_set("utf-8")

QT_BEGIN_NAMESPACE
namespace OpenQinling {
namespace C_Compiler{

}


}
QT_END_NAMESPACE
